# GitHub Submission Guide — LegalEase

## Repository Structure

```text
LegalEase/
├── ai_core/
├── backend/
├── frontend/
├── services/
├── assets/
├── tests/
├── phase_docs/
│   ├── 01_Brainstorming_Ideation/
│   ├── 02_Requirement_Analysis/
│   ├── 03_Project_Design/
│   ├── 04_Project_Planning/
│   ├── 05_Project_Development/
│   ├── 06_Project_Testing/
│   ├── 07_Project_Documentation/
│   └── 08_Project_Demonstration/
├── .streamlit/
├── .env.example
├── .gitignore
├── Dockerfile
├── docker-compose.yml
├── Procfile
├── requirements.txt
├── README.md
└── GITHUB_SUBMISSION_GUIDE.md
```

## Files That Must Not Be Uploaded
Do not upload:
- `.env`
- `.venv/`
- API keys or passwords
- `__pycache__/`
- `.pytest_cache/`

The included `.gitignore` already excludes these development secrets and generated folders.

## Basic Git Commands

```bash
git init
git add .
git commit -m "Phase 1-8 LegalEase project submission"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

## Phase-wise Commit Option
If your evaluator requires separate phase commits, use:

```bash
git add phase_docs/01_Brainstorming_Ideation
git commit -m "Phase 1 - Brainstorming and Ideation"

git add phase_docs/02_Requirement_Analysis
 git commit -m "Phase 2 - Requirement Analysis"

git add phase_docs/03_Project_Design
 git commit -m "Phase 3 - Project Design"

git add phase_docs/04_Project_Planning
 git commit -m "Phase 4 - Project Planning"

git add .
git commit -m "Phase 5 - Project Development"

git add phase_docs/06_Project_Testing tests
 git commit -m "Phase 6 - Project Testing"

git add phase_docs/07_Project_Documentation README.md
 git commit -m "Phase 7 - Project Documentation"

git add phase_docs/08_Project_Demonstration
 git commit -m "Phase 8 - Project Demonstration"

git push
```

Replace `YOUR_GITHUB_REPOSITORY_URL` with the repository URL created by the student/team.
