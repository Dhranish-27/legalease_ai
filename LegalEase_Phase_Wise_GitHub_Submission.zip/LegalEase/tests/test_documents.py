from services.document_service import sanitize_text, format_docx, format_pdf, format_html_preview

def test_sanitize():
    assert sanitize_text('A—B “C”') == 'A-B "C"'

def test_html():
    result = format_html_preview('NDA\n\n1. CONFIDENTIALITY\nKeep information private.', 'NDA')
    assert 'legal-preview' in result and 'CONFIDENTIALITY' in result

def test_docx():
    data = format_docx('NDA\n\n1. CONFIDENTIALITY\nKeep information private.', 'NDA', ['Keep information private'])
    assert data[:2] == b'PK'

def test_pdf():
    data = format_pdf('NDA\n\n1. CONFIDENTIALITY\nKeep information private.', 'NDA')
    assert data.startswith(b'%PDF')
