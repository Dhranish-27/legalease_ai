from __future__ import annotations
import os
from pathlib import Path
import html
import requests
import streamlit as st
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[1]
load_dotenv(ROOT / '.env')
API_URL = os.getenv('BACKEND_URL', 'http://127.0.0.1:8000').rstrip('/')

st.set_page_config(page_title='LegalEase', page_icon='⚖️', layout='wide', initial_sidebar_state='expanded')

st.markdown('''<style>
.main {background:#0b1020}.block-container{max-width:1200px;padding-top:1.5rem}
.hero{padding:1.5rem 1.7rem;border-radius:18px;background:linear-gradient(135deg,#111827,#1e293b);border:1px solid #334155;margin-bottom:1rem}
.hero h1{color:#f8fafc;margin:0;font-size:2.4rem}.hero p{color:#cbd5e1;margin:.35rem 0 0}
.legal-preview{background:#fff;color:#172033;border-radius:14px;padding:2rem;min-height:450px;max-height:680px;overflow:auto;box-shadow:0 8px 30px rgba(0,0,0,.25);font-family:Georgia,serif;line-height:1.65}
.legal-title{text-align:center;font-weight:800;font-size:1.4rem;margin-bottom:1.5rem;text-transform:uppercase}.legal-preview h3{font-family:Arial,sans-serif;font-size:1rem;margin-top:1.25rem}.legal-preview p{margin:.35rem 0}
.disclaimer{font-size:.82rem;color:#94a3b8;padding:.7rem 0}.stButton button{border-radius:10px}
</style>''', unsafe_allow_html=True)

st.markdown('<div class="hero"><h1>⚖️ LegalEase</h1><p>AI-assisted legal document drafting with editable previews and branded exports.</p></div>', unsafe_allow_html=True)
st.info('LegalEase creates drafts for informational use. Review every document with a qualified legal professional before signing or relying on it.')

with st.sidebar:
    st.header('Document inputs')
    document_type = st.selectbox('Document type', ['Agreement', 'Contract', 'NDA (Non-Disclosure Agreement)', 'Lease Agreement', 'Employment Offer Letter', 'Freelance Work Contract', 'Service Agreement', 'Custom'])
    if document_type == 'Custom':
        document_type = st.text_input('Custom document type', placeholder='e.g. Consulting Agreement')
    parties = st.text_area('Parties involved', placeholder='Jane Doe (Service Provider), TechNova Inc. (Client)', height=100)
    effective_date = st.text_input('Effective date', placeholder='April 10, 2025')
    terms_raw = st.text_area('Terms & conditions', placeholder='Payment within 30 days; Confidentiality applies for 2 years; Either party may terminate with 15 days notice', height=160)
    additional = st.text_area('Additional instructions (optional)', placeholder='Use plain but formal language. Include a detailed termination clause.', height=110)
    generate = st.button('Generate Document', type='primary', use_container_width=True)
    st.caption(f'Backend: {API_URL}')

if 'content' not in st.session_state:
    st.session_state.content = ''
if 'doc_type' not in st.session_state:
    st.session_state.doc_type = ''
if 'terms' not in st.session_state:
    st.session_state.terms = []

if generate:
    if not document_type.strip() or not parties.strip() or not effective_date.strip() or not terms_raw.strip():
        st.error('Please provide document type, parties, effective date, and at least one term.')
    else:
        terms = [x.strip() for x in terms_raw.split(';') if x.strip()]
        payload = {'document_type': document_type.strip(), 'parties': parties.strip(), 'terms': terms, 'effective_date': effective_date.strip(), 'additional_instructions': additional.strip()}
        with st.spinner('Drafting your document...'):
            try:
                response = requests.post(f'{API_URL}/generate', json=payload, timeout=100)
                response.raise_for_status()
                data = response.json()
                st.session_state.content = data['content']
                st.session_state.doc_type = data['document_type']
                st.session_state.terms = terms
                st.session_state.model = data.get('model', '')
                st.success('Document generated successfully.')
            except requests.RequestException as exc:
                detail = ''
                try: detail = response.json().get('detail', '')
                except Exception: pass
                st.error(f'Backend request failed. {detail or exc}')

left, right = st.columns([1.25, .75], gap='large')
with left:
    st.subheader('Preview')
    if st.session_state.content:
        preview = html.escape(st.session_state.content).replace('\n\n', '</p><p>').replace('\n', '<br>')
        st.markdown(f'<div class="legal-preview"><div class="legal-title">{html.escape(st.session_state.doc_type)}</div><p>{preview}</p></div>', unsafe_allow_html=True)
    else:
        st.markdown('<div class="legal-preview"><div class="legal-title">Your document will appear here</div><p>Enter the requested details and click Generate Document.</p></div>', unsafe_allow_html=True)

with right:
    st.subheader('Edit & export')
    edited = st.text_area('Editable document', value=st.session_state.content, height=520, label_visibility='collapsed', placeholder='Generated text appears here...')
    if edited != st.session_state.content and st.session_state.content:
        st.session_state.content = edited
        st.caption('Unsaved edits are kept in this browser session.')
    if st.session_state.content:
        from services.document_service import format_docx, format_pdf
        content = st.session_state.content
        doc_type = st.session_state.doc_type or document_type
        terms = st.session_state.terms
        st.download_button('Download TXT', content.encode('utf-8'), file_name='legalease_document.txt', mime='text/plain', use_container_width=True)
        st.download_button('Download DOCX', format_docx(content, doc_type, terms), file_name='legalease_document.docx', mime='application/vnd.openxmlformats-officedocument.wordprocessingml.document', use_container_width=True)
        st.download_button('Download PDF', format_pdf(content, doc_type), file_name='legalease_document.pdf', mime='application/pdf', use_container_width=True)
        st.caption(f"Model: {st.session_state.get('model', 'unknown')}")

st.markdown('<div class="disclaimer">AI-generated drafts can contain omissions or inaccuracies. Verify names, dates, amounts, governing law, obligations, and signatures before use.</div>', unsafe_allow_html=True)
