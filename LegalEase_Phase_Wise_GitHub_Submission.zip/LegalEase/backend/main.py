from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from backend.config import get_settings
from backend.routes import router

settings = get_settings()
app = FastAPI(title=settings.app_name, version=settings.app_version, description='AI-assisted legal document drafting API')
app.add_middleware(CORSMiddleware, allow_origins=[settings.frontend_origin, 'http://localhost:8501', 'http://127.0.0.1:8501'], allow_credentials=False, allow_methods=['GET', 'POST', 'OPTIONS'], allow_headers=['*'])
app.include_router(router)

@app.get('/')
def root():
    return {'name': settings.app_name, 'version': settings.app_version, 'status': 'running', 'docs': '/docs'}

@app.get('/health')
def health():
    return {'status': 'ok', 'mock_mode': settings.mock_mode, 'model': settings.gemini_model}
