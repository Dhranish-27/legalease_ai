from fastapi import APIRouter, HTTPException
from backend.config import get_settings
from backend.schemas import DocumentRequest, DocumentResponse
from ai_core.gemini_generator import GeminiDocumentGenerator, GeminiGenerationError
from ai_core.mock_generator import MockDocumentGenerator

router = APIRouter()
settings = get_settings()


def _generator():
    if settings.mock_mode:
        return MockDocumentGenerator(), 'mock'
    return GeminiDocumentGenerator(settings), settings.gemini_model

@router.post('/generate', response_model=DocumentResponse)
def generate_document(request: DocumentRequest):
    total = len(request.parties) + sum(len(x) for x in request.terms) + len(request.additional_instructions or '')
    if total > settings.max_input_chars:
        raise HTTPException(status_code=413, detail='Input is too large.')
    try:
        generator, model = _generator()
        content = generator.generate_document(request.document_type, request.parties, request.terms, request.effective_date, request.additional_instructions or '')
        return DocumentResponse(document_type=request.document_type, content=content, disclaimer=settings.disclaimer, model=model, mock_mode=settings.mock_mode)
    except GeminiGenerationError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f'Unexpected generation error: {exc}') from exc

@router.get('/metadata')
def metadata():
    return {'document_types': ['Agreement', 'Contract', 'NDA (Non-Disclosure Agreement)', 'Lease Agreement', 'Employment Offer Letter', 'Freelance Work Contract', 'Service Agreement', 'Custom'], 'model': settings.gemini_model, 'mock_mode': settings.mock_mode}
