# Phase 3 — Project Design Phase Phase

## Architecture

```text
User
  |
  v
Streamlit Frontend
frontend/app.py
  |
  | POST /generate
  v
FastAPI Backend
backend/main.py + backend/routes.py
  |
  +--> Pydantic validation
  |
  +--> MockDocumentGenerator (development/test)
  |
  +--> GeminiDocumentGenerator (real AI)
             |
             v
       Google Gemini API

Generated text
  |
  v
Editable preview
  |
  +--> TXT
  +--> DOCX
  +--> PDF
```

## Main Modules
- `frontend/` — Streamlit user interface.
- `backend/` — API, configuration, schemas, and routes.
- `ai_core/` — Gemini and mock generation logic.
- `services/` — document formatting/export services.
- `tests/` — automated tests.
- `assets/` — application logo.
- `.streamlit/` — Streamlit configuration.

## API Design

### POST `/generate`
Accepts:
- `document_type`
- `parties`
- `terms`
- `effective_date`
- `additional_instructions`

Returns:
- generation success flag
- document type
- generated content
- disclaimer
- model identifier
- mock-mode status

### GET `/health`
Returns application health information.

### GET `/metadata`
Returns supported document types and model configuration.

## Data Flow
1. User enters document information.
2. Streamlit validates basic required fields.
3. Streamlit sends JSON to FastAPI.
4. FastAPI validates the request with Pydantic.
5. Selected generator creates the document.
6. Generated content is returned to Streamlit.
7. User edits the document if required.
8. Export services generate TXT/DOCX/PDF output.

## Security Design
- API keys are loaded from environment variables.
- `.env` is excluded by `.gitignore`.
- The Gemini key is not placed in frontend code.
- Public deployment should add authentication and rate limiting.
