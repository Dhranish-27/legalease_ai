# Phase 1 — Brainstorming & Ideation

## Project Name
**LegalEase — AI-Powered Legal Document Generator**

## Problem Identified
Creating a first draft of a legal agreement manually can be time-consuming and difficult for users who do not know the expected structure and wording of common documents.

## Proposed Idea
LegalEase is an AI-assisted application that accepts document type, parties, effective date, and requested terms, then generates an editable legal-document draft. The user can preview, edit, and export the generated document.

## Core Idea
- Simple web interface for document inputs.
- AI-assisted legal drafting using Google Gemini.
- FastAPI backend for document-generation requests.
- Streamlit frontend for user interaction.
- Editable generated-document preview.
- TXT, DOCX, and PDF export.
- Demo/mock mode for development and testing without an API key.

## Target Users
- Students demonstrating AI application development.
- Individuals preparing initial document drafts.
- Small teams that need structured first drafts.
- Developers demonstrating generative-AI integration.

## Initial Feature Ideas
1. Agreement/contract generation.
2. NDA generation.
3. Lease/service/freelance document generation.
4. Custom document type.
5. Terms and conditions input.
6. Effective-date input.
7. Editable output.
8. Branded DOCX/PDF export.

## Expected Outcome
A working prototype that demonstrates end-to-end generative-AI document creation while clearly stating that generated drafts require review before use.
