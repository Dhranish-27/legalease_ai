# Phase 5 — Project Development

## Implemented Components

### Frontend
`frontend/app.py` implements:
- document-type selection
- party input
- effective-date input
- terms input
- additional instructions
- generation button
- editable document area
- TXT/DOCX/PDF downloads

### Backend
`backend/main.py` and `backend/routes.py` implement:
- FastAPI application
- CORS configuration
- `/generate`
- `/health`
- `/metadata`

### AI Core
`ai_core/gemini_generator.py` implements:
- Gemini client initialization
- controlled prompt creation
- configurable model use
- generation error handling

`ai_core/mock_generator.py` implements a deterministic local generator for development and testing.

### Document Services
`services/document_service.py` implements:
- text sanitization
- HTML preview formatting
- DOCX generation
- PDF generation
- logo support
- terms table for DOCX
- PDF header/footer

## Configuration
Use `.env.example` as the template. Do not commit a real `.env` file or API key.

## Running the Project
```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

Backend:
```powershell
uvicorn backend.main:app --reload --host 127.0.0.1 --port 8000
```

Frontend:
```powershell
streamlit run frontend/app.py
```

## Development Completion Criteria
The development phase is complete when the complete input → API → generation → edit → export workflow operates locally.
