# Phase 2 — Requirement Analysis

## Functional Requirements

### Input Requirements
- Select or enter a document type.
- Enter the parties involved.
- Enter the effective date.
- Enter requested terms and conditions.
- Optionally provide additional drafting instructions.

### Generation Requirements
- Send validated input from the frontend to the FastAPI backend.
- Generate a document through Gemini in real-AI mode.
- Provide a deterministic mock generator in development mode.
- Preserve supplied facts and terms.
- Avoid inventing missing legal facts.
- Use placeholders when an essential fact is missing.

### Output Requirements
- Show generated content in an editable interface.
- Download the document as TXT.
- Download the document as DOCX.
- Download the document as PDF.
- Include branding and document formatting where supported.

## Non-Functional Requirements
- Python-based implementation.
- Streamlit frontend.
- FastAPI backend.
- Configurable Gemini model and API key.
- Environment-variable configuration.
- Input validation with Pydantic.
- Automated tests.
- GitHub-compatible project structure.

## Technology Requirements
- Python 3.10+; Python 3.12 recommended.
- FastAPI and Uvicorn.
- Streamlit.
- Pydantic / pydantic-settings.
- Google `google-genai` SDK.
- python-docx for DOCX export.
- fpdf2 for PDF export.
- Pillow for logo handling.
- pytest and httpx for testing.

## Constraints and Safety
LegalEase is an AI-assisted drafting tool. It must not present generated documents as attorney-reviewed or as guaranteed legally valid in a specific jurisdiction. Users should review generated documents before use.

## Acceptance Criteria
A submission is considered functional when the application can:
1. Start the FastAPI backend.
2. Start the Streamlit frontend.
3. Accept valid document inputs.
4. Generate a draft in mock mode.
5. Generate through Gemini when configured.
6. Edit the output.
7. Download TXT, DOCX, and PDF files.
8. Pass the automated test suite.
