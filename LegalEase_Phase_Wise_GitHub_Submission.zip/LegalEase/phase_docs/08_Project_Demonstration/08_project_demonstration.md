# Phase 8 — Project Demonstration

## Demonstration Objective
Demonstrate the complete LegalEase workflow from user input through AI-assisted generation, editing, and document export.

## Recommended Demo Sequence

### 1. Introduce the Problem
Explain that LegalEase helps users create structured first drafts of common legal documents using an AI-assisted workflow.

### 2. Show the Architecture
Briefly show:
- Streamlit frontend
- FastAPI backend
- Gemini integration
- document export service

### 3. Enter Sample Data
Use:
- Document type: `Freelance Work Contract`
- Parties: `Jane Doe (Service Provider), TechNova Inc. (Client)`
- Effective date: `April 10, 2025`
- Terms: payment within 30 days; confidentiality; delivery deadline; 15-day termination notice

### 4. Generate
Click **Generate Document** and show the generated draft.

### 5. Edit
Modify one or more clauses in the editable document area.

### 6. Export
Demonstrate:
- TXT download
- DOCX download
- PDF download

### 7. Show Testing
Run:
```powershell
pytest -q
```
and show the passing test result.

### 8. Show API Documentation
Open:
`http://127.0.0.1:8000/docs`

### 9. Explain Safety
State that LegalEase is an AI-assisted drafting tool and that generated documents should be reviewed before signing or relying on them.

## Demonstration Evidence Checklist
- [ ] Project home page screenshot
- [ ] Input form screenshot
- [ ] Generated document screenshot
- [ ] Edited document screenshot
- [ ] TXT/DOCX/PDF evidence
- [ ] API docs screenshot
- [ ] Test result screenshot
- [ ] GitHub repository screenshot

## Final Submission
The GitHub repository should contain the full source code, project documentation, phase-wise documents, tests, configuration templates, and demonstration evidence that is permitted by the submission rules.
