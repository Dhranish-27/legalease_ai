# Phase 6 — Project Testing

## Automated Test Areas
The project includes tests for:
- FastAPI root endpoint.
- FastAPI health endpoint.
- Successful mock generation.
- Request validation failure.
- Text sanitization.
- HTML preview generation.
- DOCX generation.
- PDF generation.

## Test Command
```powershell
pytest -q
```

## Expected Result
The supplied test suite is designed to report **8 passed** for the current implementation.

## Manual Test Procedure
1. Start the backend.
2. Start Streamlit.
3. Select a document type.
4. Enter two or more parties.
5. Enter an effective date.
6. Enter several terms separated by semicolons.
7. Generate the document.
8. Confirm the preview is displayed.
9. Edit the generated text.
10. Download TXT.
11. Download DOCX.
12. Download PDF.
13. Open the downloaded files and verify the content.

## AI Mode Testing
First test with:
```env
MOCK_MODE=true
```
Then configure a valid Gemini API key and test:
```env
MOCK_MODE=false
```

## Test Evidence to Capture
- Screenshot of the running Streamlit page.
- Screenshot of successful document generation.
- Screenshot of the editable output.
- Screenshot or files showing TXT/DOCX/PDF downloads.
- Terminal screenshot showing `pytest -q` passing.
- Screenshot of FastAPI `/docs` if required by the evaluator.
