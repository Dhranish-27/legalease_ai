# LegalEase — Phase-wise Project Submission

This folder contains the eight required phase-wise submissions for the LegalEase project.

## Required phases
1. Brainstorming & Ideation Phase
2. Requirement Analysis Phase
3. Project Design Phase Phase
4. Project Planning Phase
5. Project Development Phase
6. Project Testing Phase
7. Project Documentation Phase
8. Project Demonstration Phase

Each phase contains a Markdown document describing the work, outputs, and evidence to submit.
